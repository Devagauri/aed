package banking;

class BankAccount {
    private int balance = 1000; // Initial balance

    public synchronized void deposit(int amount, String user) {
        balance += amount;
        System.out.println(user + " deposited $" + amount + ". Balance: $" + balance);
    }

    public synchronized void withdraw(int amount, String user) {
        if (balance >= amount) {
            balance -= amount;
            System.out.println(user + " withdrew $" + amount + ". Balance: $" + balance);
        } else {
            System.out.println(user + " tried to withdraw $" + amount + " but insufficient balance! Current Balance: $" + balance);
        }
    }
}

class UserOperation extends Thread {
    private BankAccount account;
    private String userName;

    public UserOperation(BankAccount account, String userName) {
        this.account = account;
        this.userName = userName;
    }

    @Override
    public void run() {
        // Randomly deposit and withdraw
        for (int i = 0; i < 3; i++) {
            int depositAmount = (int)(Math.random() * 500);
            int withdrawAmount = (int)(Math.random() * 500);

            account.deposit(depositAmount, userName);
            try {
                Thread.sleep(500); // small pause
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            account.withdraw(withdrawAmount, userName);
        }
    }
}

public class BankingStimulation {
    public static void main(String[] args) {
        BankAccount sharedAccount = new BankAccount();

        UserOperation user1 = new UserOperation(sharedAccount, "Alice");
        UserOperation user2 = new UserOperation(sharedAccount, "Bob");
        UserOperation user3 = new UserOperation(sharedAccount, "Charlie");

        user1.start();
        user2.start();
        user3.start();
    }
}
