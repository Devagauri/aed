// CalculatorServer.java
import java.io.*;
import java.net.*;

public class CalculatorServer {
    public static void main(String[] args) {
        int port = 12345;
        
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Calculator Server is running on port " + port);
            
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("New client connected: " + clientSocket.getInetAddress());
                
                // Handle each client in a separate thread
                new ClientHandler(clientSocket).start();
            }
        } catch (IOException e) {
            System.err.println("Server exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

class ClientHandler extends Thread {
    private Socket clientSocket;
    
    public ClientHandler(Socket socket) {
        this.clientSocket = socket;
    }
    
    public void run() {
        try (
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
        ) {
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                System.out.println("Received from client: " + inputLine);
                
                try {
                    String[] parts = inputLine.split(" ");
                    if (parts.length != 3) {
                        out.println("ERROR: Invalid format. Use: OPERATION NUMBER1 NUMBER2");
                        continue;
                    }
                    
                    String operation = parts[0];
                    double num1 = Double.parseDouble(parts[1]);
                    double num2 = Double.parseDouble(parts[2]);
                    double result;
                    
                    switch (operation.toLowerCase()) {
                        case "add":
                            result = num1 + num2;
                            break;
                        case "subtract":
                            result = num1 - num2;
                            break;
                        case "multiply":
                            result = num1 * num2;
                            break;
                        case "divide":
                            if (num2 == 0) {
                                out.println("ERROR: Division by zero");
                                continue;
                            }
                            result = num1 / num2;
                            break;
                        default:
                            out.println("ERROR: Invalid operation. Use add, subtract, multiply, or divide");
                            continue;
                    }
                    
                    out.println("RESULT: " + result);
                } catch (NumberFormatException e) {
                    out.println("ERROR: Invalid numbers provided");
                }
            }
            
            System.out.println("Client disconnected: " + clientSocket.getInetAddress());
            clientSocket.close();
        } catch (IOException e) {
            System.err.println("Error handling client: " + e.getMessage());
        }
    }
}