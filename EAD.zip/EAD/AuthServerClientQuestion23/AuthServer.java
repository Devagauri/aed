import java.sql.*;
import java.io.*;
import java.net.*;

public class AuthServer {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/auth_system";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "root";
    private static final int PORT = 33456;

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Authentication Server running on port " + PORT);
            
            while (true) {
                Socket clientSocket = serverSocket.accept();
                new ClientHandler(clientSocket).start();
            }
        } catch (IOException e) {
            System.err.println("Server error: " + e.getMessage());
        }
    }

    static class ClientHandler extends Thread {
        private final Socket clientSocket;

        public ClientHandler(Socket socket) {
            this.clientSocket = socket;
        }

        public void run() {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                 PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {
                
                // Send input format instructions
                out.println("=== AUTHENTICATION REQUIRED ===");
                out.println("FORMAT: username:password");
                out.println("EXAMPLE: admin:admin123");
                out.println("END_INSTRUCTIONS"); // Marks end of instructions

                String credentials = in.readLine();
                System.out.println("Received credentials: " + credentials);

                if (credentials == null || !credentials.contains(":")) {
                    out.println("ERROR: Invalid format. Use username:password");
                    return;
                }

                String[] parts = credentials.split(":");
                if (parts.length != 2) {
                    out.println("ERROR: Invalid format. Use username:password");
                    return;
                }

                String username = parts[0].trim();
                String password = parts[1].trim();

                if (validateCredentials(username, password)) {
                    out.println("SUCCESS: Authenticated as " + username);
                } else {
                    out.println("ERROR: Invalid credentials");
                }

            } catch (IOException e) {
                System.err.println("Client error: " + e.getMessage());
            } finally {
                try {
                    clientSocket.close();
                } catch (IOException e) {
                    System.err.println("Socket close error: " + e.getMessage());
                }
            }
        }

        private boolean validateCredentials(String username, String password) {
            String query = "SELECT * FROM users WHERE username = ? AND password = SHA2(?, 256)";

            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                 PreparedStatement stmt = conn.prepareStatement(query)) {

                stmt.setString(1, username);
                stmt.setString(2, password);
                return stmt.executeQuery().next();

            } catch (SQLException e) {
                System.err.println("Database error: " + e.getMessage());
                return false;
            }
        }
    }
}