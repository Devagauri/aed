import java.io.*;
import java.net.*;
import java.util.Scanner;

public class AuthClient {
    private static final String HOST = "localhost";
    private static final int PORT = 33456;

    public static void main(String[] args) {
        try (Socket socket = new Socket(HOST, PORT);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             Scanner scanner = new Scanner(System.in)) {
            
            // Display server instructions
            String line;
            while (!(line = in.readLine()).equals("END_INSTRUCTIONS")) {
                System.out.println(line);
            }

            while (true) {
                System.out.print("\nEnter credentials (username:password) or 'exit': ");
                String input = scanner.nextLine();

                if (input.equalsIgnoreCase("exit")) {
                    break;
                }

                out.println(input);
                System.out.println("Server response: " + in.readLine());
            }

        } catch (UnknownHostException e) {
            System.err.println("Server not found: " + HOST);
        } catch (IOException e) {
            System.err.println("Connection error: " + e.getMessage());
        }
        System.out.println("Client terminated");
    }
}