package deadlock;

class DeadlockResolved {
    static class Friend {
        private final String name;

        Friend(String name) {
            this.name = name;
        }

        void bow(Friend bower) {
            Friend first = this.name.compareTo(bower.name) < 0 ? this : bower;
            Friend second = this.name.compareTo(bower.name) < 0 ? bower : this;

            synchronized (first) {
                synchronized (second) {
                    System.out.println(this.name + " is bowing to " + bower.name);
                    bower.bowBack(this);
                }
            }
        }

        synchronized void bowBack(Friend bower) {
            System.out.println(this.name + " is bowing back to " + bower.name);
        }
    }

    public static void main(String[] args) {
        Friend alice = new Friend("Alice");
        Friend bob = new Friend("Bob");

        new Thread(() -> alice.bow(bob)).start();
        new Thread(() -> bob.bow(alice)).start();
    }
}
