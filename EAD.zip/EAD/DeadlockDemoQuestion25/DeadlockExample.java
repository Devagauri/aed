package deadlock;

class DeadlockExample {
    static class Friend {
        private final String name;

        Friend(String name) {
            this.name = name;
        }

        synchronized void bow(Friend bower) {
            System.out.println(this.name + " is trying to bow to " + bower.name);
            bower.bowBack(this);
        }

        synchronized void bowBack(Friend bower) {
            System.out.println(this.name + " is bowing back to " + bower.name);
        }
    }

    public static void main(String[] args) {
        Friend alice = new Friend("Alice");
        Friend bob = new Friend("Bob");

        new Thread(() -> alice.bow(bob)).start();
        new Thread(() -> bob.bow(alice)).start();
    }
}
