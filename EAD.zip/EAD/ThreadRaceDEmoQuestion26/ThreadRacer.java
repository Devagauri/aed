package race;

class Racer extends Thread {
    private String name;

    public Racer(String name) {
        this.name = name;
    }

    @Override
    public void run() {
        System.out.println(name + " has started racing!");

        try {
            for (int i = 1; i <= 5; i++) {
                System.out.println(name + " is at position " + i);
                Thread.sleep((int)(Math.random() * 1000)); // Random delay
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println(name + " has finished the race!");
    }
}

public class ThreadRacer {
    public static void main(String[] args) {
        Racer racer1 = new Racer("Bolt");
        Racer racer2 = new Racer("Flash");
        Racer racer3 = new Racer("Speedy");

        racer1.start();
        racer2.start();
        racer3.start();
    }
}
